package com.example.realestate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
